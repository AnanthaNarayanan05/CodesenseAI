"""
main.py
-------
CodeSense — AI Code Review Assistant
Streamlit entry point.

All UI rendering is delegated to the components/ package.
This file handles: layout, sidebar, API calls, and orchestration.

Run with:
    streamlit run app/main.py
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent.parent))

import json
import streamlit as st
from dotenv import load_dotenv
import os
import matplotlib.pyplot as plt

load_dotenv()

from core.prompts import PromptMode, MODE_DESCRIPTIONS, get_prompt
from core.claude_client import ClaudeReviewer, ReviewResult

from components.cot_viewer import render_cot_chain
from components.findings_card import render_findings
from components.radar_chart import render_radar_chart
from components.compare_panel import render_comparison
from components.history_panel import add_to_history, render_history_sidebar, render_history_main

# ── Page config ────────────────────────────────────────────────
st.set_page_config(
    page_title="CodeSense — AI Code Review",
    page_icon="🔍",
    layout="wide",
)

ANTHROPIC_KEY = os.getenv("ANTHROPIC_API_KEY", "")
OPENAI_KEY    = os.getenv("OPENAI_API_KEY", "")

# ══════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════
with st.sidebar:
    st.title("⚙️ Configuration")

    offline_simulation = st.checkbox(
        "Offline Simulation Mode",
        value=False,
        help="Simulate the app's reviews and features locally without connecting to live LLM APIs.",
    )

    if offline_simulation:
        anthropic_key = "sk-ant-mock-key"
        openai_key = "sk-mock-key"
        st.success("Simulation keys loaded.")
    else:
        anthropic_key = st.text_input(
            "Anthropic API key",
            value=ANTHROPIC_KEY,
            type="password",
            placeholder="sk-ant-...",
        )
        openai_key = st.text_input(
            "OpenAI API key (optional)",
            value=OPENAI_KEY,
            type="password",
            placeholder="sk-... (for comparison mode)",
        )

    st.divider()
    st.subheader("Prompt mode")
    mode = st.radio(
        "Select prompting technique",
        options=[m.value for m in PromptMode],
        index=2,
        help="Switches the system prompt used for the review.",
    )
    selected_mode = PromptMode(mode)
    st.caption(MODE_DESCRIPTIONS[selected_mode])

    st.divider()
    show_comparison = st.checkbox(
        "Compare with GPT-4o",
        value=False,
        disabled=not openai_key,
        help="Sends the same code to GPT-4o and shows results side-by-side.",
    )
    show_prompt = st.checkbox("Show Prompt Inspector", value=False)
    show_history_table = st.checkbox("Show full history table", value=False)

    st.divider()
    render_history_sidebar()

# ══════════════════════════════════════════════════════════════
# MAIN PANEL
# ══════════════════════════════════════════════════════════════
st.title("🔍 CodeSense")
st.caption("AI Code Review Assistant · Chain-of-Thought Edition · IT742E06 Prompt Engineering")
if offline_simulation:
    st.info("⚡ **Offline Simulation Mode Active**: Running reviews using local pre-computed responses.")

# ── Demo snippet loader ─────────────────────────────────────────
DEMOS = {
    "None": ("", "Python"),
    "Python — eval() RCE bug": (
        'def calculate(user_input):\n    result = eval(user_input)   # Critical: arbitrary code execution\n    return result\n\nprint(calculate(input("Enter expression: ")))',
        "Python",
    ),
    "Python — SQL injection": (
        "import sqlite3\n\ndef get_user(username):\n    conn = sqlite3.connect('users.db')\n    cursor = conn.cursor()\n    query = \"SELECT * FROM users WHERE name = '\" + username + \"'\"\n    cursor.execute(query)\n    return cursor.fetchall()",
        "Python",
    ),
    "JavaScript — async/await bug": (
        "function fetchUserProfile(userId) {\n  let profile;\n  fetch(`/api/users/${userId}`)\n    .then(response => response.json())\n    .then(data => { profile = data; });\n  return profile;   // always undefined\n}",
        "JavaScript",
    ),
    "Python — O(n³) performance": (
        "def find_duplicates(lst):\n    duplicates = []\n    for i in range(len(lst)):\n        for j in range(len(lst)):\n            if i != j and lst[i] == lst[j]:\n                if lst[i] not in duplicates:\n                    duplicates.append(lst[i])\n    return duplicates",
        "Python",
    ),
    "Java — multiple anti-patterns": (
        'public class UserManager {\n    public List<String> users = new ArrayList<>();\n\n    public void addUser(String name) {\n        try {\n            if (name != "") {   // Bug: should use .equals()\n                users.add(name);\n            }\n        } catch (Exception e) {  // Too broad\n        }\n    }\n\n    public String listUsers() {\n        String result = "";\n        for (String user : users) {\n            result += user + ", ";  // O(n²) memory\n        }\n        return result;\n    }\n}',
        "Java",
    ),
}

demo_choice = st.selectbox("Load a demo snippet", options=list(DEMOS.keys()))
demo_code, demo_lang = DEMOS[demo_choice]

col_input, col_lang = st.columns([4, 1])
with col_input:
    code_input = st.text_area(
        "Paste your code here",
        value=demo_code,
        height=220,
        placeholder="Paste any Python, JavaScript, Java, C++, SQL, or other code...",
    )
with col_lang:
    lang_options = ["Python", "JavaScript", "Java", "C++", "SQL",
                    "TypeScript", "Go", "Rust", "Other"]
    default_idx = lang_options.index(demo_lang) if demo_lang in lang_options else 0
    language = st.selectbox("Language", lang_options, index=default_idx)

# ── Prompt Inspector ────────────────────────────────────────────
if show_prompt and code_input.strip():
    with st.expander("📋 Prompt Inspector — raw prompt sent to model", expanded=False):
        system, user_fn = get_prompt(selected_mode)
        st.markdown("**System prompt:**")
        st.code(system, language="text")
        st.markdown("**User message:**")
        st.code(user_fn(code=code_input, language=language), language="text")

# ── Action button ───────────────────────────────────────────────
col_btn, col_warn = st.columns([1, 3])
with col_btn:
    run_review = st.button(
        "🔍 Run Code Review",
        type="primary",
        disabled=not code_input.strip() or not anthropic_key,
        use_container_width=True,
    )
with col_warn:
    if not anthropic_key:
        st.warning("Add your Anthropic API key in the sidebar to run reviews.")

# ── History table ───────────────────────────────────────────────
if show_history_table:
    st.divider()
    st.subheader("📋 Full Review History")
    render_history_main()
    st.divider()

# ══════════════════════════════════════════════════════════════
# RESULT RENDERER
# ══════════════════════════════════════════════════════════════
def _render_result(result: ReviewResult) -> None:
    """Orchestrates all result component renders for a single ReviewResult."""

    # CoT chain viewer
    if result.mode == PromptMode.COT:
        render_cot_chain(result)
        st.divider()

    # Quality scorecard
    s = result.scores
    if s.average() > 0:
        st.subheader("📊 Quality Scorecard")
        col_chart, col_metrics = st.columns([1, 1])

        with col_chart:
            fig = render_radar_chart(s, title="Code Quality")
            st.pyplot(fig)
            plt.close(fig)

        with col_metrics:
            dims = [
                ("Correctness",     s.correctness),
                ("Security",        s.security),
                ("Readability",     s.readability),
                ("Efficiency",      s.efficiency),
                ("Maintainability", s.maintainability),
            ]
            for label, val in dims:
                icon = "🟢" if val >= 7 else "🟡" if val >= 4 else "🔴"
                st.metric(label, f"{icon} {val}/10")
            st.caption(f"**Average: {s.average()}/10**")

        st.divider()

    # Findings cards
    render_findings(result)

    # Refactored code
    if result.refactored_code:
        st.divider()
        with st.expander("✨ Refactored Code", expanded=False):
            st.code(result.refactored_code, language=result.language.lower())

    # Verdict
    if result.verdict:
        st.divider()
        st.subheader("📝 Final Verdict")
        sev_colour = result.severity_color
        if sev_colour == "red":
            st.error(result.verdict)
        elif sev_colour == "orange":
            st.warning(result.verdict)
        else:
            st.success(result.verdict)

    # Raw response toggle
    with st.expander("🔬 Raw model output", expanded=False):
        try:
            data = json.loads(result.raw_response)
            raw = data.get("full_text", result.raw_response)
        except (json.JSONDecodeError, TypeError):
            raw = result.raw_response
        st.text(raw)


# ══════════════════════════════════════════════════════════════
# REVIEW EXECUTION
# ══════════════════════════════════════════════════════════════
if run_review and code_input.strip() and anthropic_key:

    reviewer = ClaudeReviewer(api_key=anthropic_key)

    # ── Structured (JSON) mode — non-streaming ─────────────────
    if selected_mode == PromptMode.STRUCTURED:
        with st.spinner("Running structured review…"):
            try:
                result = reviewer.review(code_input, language, selected_mode)
                st.success(
                    f"Done · {result.input_tokens + result.output_tokens} tokens "
                    f"· {result.latency_ms}ms"
                )
                _render_result(result)
                add_to_history(result, code_input)
            except (ValueError, RuntimeError) as e:
                st.error(str(e))

    # ── Streaming modes (ZeroShot / FewShot / CoT) ─────────────
    else:
        if show_comparison and openai_key:
            col_claude, col_gpt = st.columns(2)
        else:
            col_claude = st.container()

        # Claude — streaming
        with col_claude:
            if show_comparison:
                st.subheader("🟣 Claude")
            status = st.empty()
            stream_box = st.empty()
            status.info(f"Running {selected_mode.value} review with Claude…")
            full_text = ""
            claude_result = None

            try:
                gen = reviewer.stream_review(code_input, language, selected_mode)
                try:
                    while True:
                        chunk = next(gen)
                        full_text += chunk
                        stream_box.markdown(
                            f"<div style='font-family:monospace;font-size:12px;"
                            f"white-space:pre-wrap;background:var(--background-color);"
                            f"padding:10px;border-radius:8px'>{full_text}</div>",
                            unsafe_allow_html=True,
                        )
                except StopIteration as e:
                    claude_result = e.value

                status.success(
                    f"✅ Claude done · "
                    f"{claude_result.input_tokens + claude_result.output_tokens} tokens "
                    f"· {claude_result.latency_ms}ms"
                )
                stream_box.empty()
                _render_result(claude_result)
                add_to_history(claude_result, code_input)

            except (ValueError, RuntimeError) as e:
                status.error(str(e))

        # GPT-4o — streaming (comparison mode)
        if show_comparison and openai_key:
            with col_gpt:
                st.subheader("🟢 GPT-4o")
                gpt_status = st.empty()
                gpt_box = st.empty()
                gpt_status.info(f"Running {selected_mode.value} review with GPT-4o…")
                gpt_text = ""
                gpt_result = None

                try:
                    from core.openai_client import GPTReviewer
                    gpt_reviewer = GPTReviewer(api_key=openai_key)
                    gpt_gen = gpt_reviewer.stream_review(code_input, language, selected_mode)
                    try:
                        while True:
                            chunk = next(gpt_gen)
                            gpt_text += chunk
                            gpt_box.markdown(
                                f"<div style='font-family:monospace;font-size:12px;"
                                f"white-space:pre-wrap;background:var(--background-color);"
                                f"padding:10px;border-radius:8px'>{gpt_text}</div>",
                                unsafe_allow_html=True,
                            )
                    except StopIteration as e:
                        gpt_result = e.value

                    gpt_status.success(
                        f"✅ GPT-4o done · "
                        f"{gpt_result.input_tokens + gpt_result.output_tokens} tokens "
                        f"· {gpt_result.latency_ms}ms"
                    )
                    gpt_box.empty()
                    _render_result(gpt_result)

                except (ValueError, RuntimeError) as e:
                    gpt_status.error(str(e))

            # Full comparison panel below
            if claude_result and gpt_result:
                st.divider()
                render_comparison(claude_result, gpt_result)


