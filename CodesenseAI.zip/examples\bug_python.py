# examples/bug_python.py
# Demo 1: Python — eval() arbitrary code execution (Critical Security)

def calculate(user_input):
    result = eval(user_input)   # L3: CRITICAL — arbitrary code execution
    return result

# Also has: no input validation, no error handling, no type hints
print(calculate(input("Enter expression: ")))
