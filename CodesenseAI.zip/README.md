# 🔍 CodeSense — AI Code Review Assistant

> **IT742E06 Prompt Engineering · CIA-3 Mini Project**  
> A Chain-of-Thought powered code review tool that makes AI reasoning visible.

---

CodeSenseAi is an advanced, AI-driven code review assistant designed to elevate software reliability and code quality by leveraging the power of Large Language Models (LLMs) through sophisticated prompt engineering. While traditional static analysis tools like Pylint or ESLint are highly effective at catching syntactic and stylistic errors, they fundamentally lack the contextual awareness required to identify complex semantic logic flaws, architectural compromises, or nuanced security vulnerabilities. CodeSenseAi bridges this critical gap by employing state-of-the-art LLMs—specifically the Anthropic Claude API and OpenAI’s GPT-4o—to deliver deep, context-aware, and actionable code evaluations.

At the heart of CodeSenseAi is its implementation of Chain-of-Thought (CoT) prompting. Rather than relying on simple, single-turn prompts that often yield erratic or superficial feedback, the platform enforces a rigorous five-step reasoning sequence: Understand, Identify, Classify, Suggest, and Score. This structured methodology compels the AI to systematically articulate the code’s function, enumerate potential issues without bias, accurately classify their severity, propose concrete code remediations, and finally, evaluate the overall code quality. Each review concludes with a comprehensive, five-axis quality scorecard that grades the snippet on Correctness, Security, Readability, Efficiency, and Maintainability.

A standout feature of CodeSenseAi is its multi-modal and dual-model architecture. The platform allows developers to dynamically toggle between Zero-Shot, Few-Shot, and Chain-of-Thought prompting strategies, providing real-time visibility into how different prompting techniques directly impact the depth and accuracy of the review. Furthermore, CodeSenseAi features a unique side-by-side comparison interface that dispatches identical prompts to both Claude and GPT-4o simultaneously. This dual-model approach generates automated overlap analysis and divergence metrics, demonstrating how complementary LLMs can uncover a broader spectrum of issues—ranging from critical security exploits to best-practice styling conventions—than either model could independently.

Ultimately, CodeSenseAi serves as a robust, prompt-engineering-first framework that validates Chain-of-Thought as the optimal paradigm for complex analytical tasks. By mitigating anchoring bias and exposing the model's logical deduction step-by-step, it consistently uncovers more vulnerabilities and provides significantly more organized, actionable feedback, making it an indispensable tool for modern software engineering teams focused on maintaining the highest standards of code integrity.

---

## What This Project Does

CodeSense takes any code snippet and produces a structured, step-by-step review using three prompting techniques:

| Mode | What the model does | Syllabus mapping |
|---|---|---|
| **Zero-Shot** | Reviews code directly from training knowledge | U2 — Prompt anatomy |
| **Few-Shot** | Two worked examples calibrate output format before your code is reviewed | U3 — Few-shot prompting |
| **Chain-of-Thought** | Forced 5-step reasoning chain shown live | U3 — CoT prompting ✅ core feature |
| **Structured (JSON)** | Returns a typed JSON object parsed into UI cards | U4 — Function calling / CO4 |

The key differentiator from a chatbot: **the CoT reasoning chain is fully visible**. Users watch the model think through Understand → Identify → Classify → Suggest → Score in real time before producing its verdict.

---

## Architecture

```
User pastes code
       │
       ▼
┌─────────────────────┐
│   Streamlit UI      │  ← main.py
│  (mode selector,    │
│   code editor,      │
│   result panels)    │
└────────┬────────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌───────┐  ┌──────────┐
│Claude │  │  GPT-4o  │   ← claude_client.py / openai_client.py
│ API   │  │   API    │     (same prompt, different model)
└───┬───┘  └────┬─────┘
    │            │
    ▼            ▼
┌──────────────────────┐
│   prompts.py         │  ← Zero-Shot / Few-Shot / CoT / Structured
│   (4 templates)      │     templates selected by mode
└──────────────────────┘
         │
         ▼
┌──────────────────────┐
│   Response parsers   │  ← _parse_cot_steps() / _parse_json_response()
│   (text → structs)   │
└──────────────────────┘
         │
         ▼
┌──────────────────────┐
│   UI rendering       │  ← CoT step viewer, findings cards,
│   (Streamlit)        │     radar scorecard, side-by-side diff
└──────────────────────┘
```

---

## Course Outcome Coverage

| CO | Description | Features that cover it | Coverage |
|---|---|---|---|
| CO1 | Understand Gen AI and LLMs | README theory section, API usage | 60% |
| CO2 | Apply prompting techniques | All 4 prompt modes, Prompt Inspector | **95%** |
| CO3 | Analyse prompting strategies | Mode comparison, quality scorecard | **85%** |
| CO4 | Develop function-calling prompts | Structured JSON mode | 50% |
| CO5 | Model-specific optimization | Claude vs GPT-4o comparison panel | **90%** |

---

## Project Structure

```
codesense/
├── app/
│   └── main.py              # Streamlit entry point — all UI logic
├── core/
│   ├── prompts.py           # ★ All 4 prompt templates + PromptMode enum
│   ├── claude_client.py     # ★ Anthropic API wrapper, ReviewResult dataclass
│   ├── openai_client.py     # OpenAI GPT-4o wrapper (comparison mode)
│   └── __init__.py
├── components/
│   ├── compare_panel.py     # Renders side-by-side comparisons
│   ├── cot_viewer.py        # CoT step expanders
│   ├── findings_card.py     # Styled findings cards
│   ├── history_panel.py     # Sidebar and main history
│   └── radar_chart.py       # Radar chart quality scorecard
├── examples/
│   ├── bug_python.py        # eval() RCE — Critical Security
│   ├── sqli_python.py       # SQL injection — Critical Security
│   ├── async_js.js          # Async/await bug — Critical Bug
│   ├── performance_python.py# O(n³) algorithm — Major Performance
│   └── antipattern_java.java# 5 anti-patterns — Mixed severity
├── .env.example             # API key template
├── requirements.txt
└── README.md
```

---

## Setup and Run

### 1. Clone / download the project

```bash
cd codesense
```

### 2. Create a virtual environment

```bash
python -m venv venv
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Add your API keys

```bash
cp .env.example .env
# Edit .env and add your keys:
#   ANTHROPIC_API_KEY=sk-ant-...
#   OPENAI_API_KEY=sk-...        (optional)
```

Get your Anthropic key at: https://console.anthropic.com/  
Get your OpenAI key at: https://platform.openai.com/api-keys

### 5. Run the app

```bash
streamlit run app/main.py
```

The app opens at `http://localhost:8501`

---

## How to Use

1. **Paste code** in the editor or load a demo snippet from the dropdown.
2. **Select language** from the dropdown (auto-detected from demo snippets).
3. **Choose a prompt mode** in the sidebar:
   - Start with Zero-Shot to see the baseline.
   - Switch to CoT — notice how the 5 reasoning steps appear before the verdict.
4. **Click "Run code review"**.
5. **Explore the output:**
   - Expand each CoT step to see the model's reasoning chain.
   - Check the quality scorecard (radar scores out of 10).
   - Expand findings cards sorted by severity.
   - View the refactored code suggestion.
6. **Enable "Show raw prompt"** in the sidebar (Prompt Inspector) to see exactly what was sent to the model.
7. **Enable "Compare with GPT-4o"** (add OpenAI key) to see both models side-by-side.

---

## The 5-Step CoT Prompt Explained

The Chain-of-Thought system prompt forces this exact reasoning sequence:

```
STEP 1 — UNDERSTAND   What does this code do? (2–3 sentences)
STEP 2 — IDENTIFY     List every potential issue, no classifications yet
STEP 3 — CLASSIFY     Category + Severity + Line reference for each issue
STEP 4 — SUGGEST      Corrected code snippet for every Critical/Major issue
STEP 5 — SCORE        Correctness / Security / Readability / Efficiency /
                      Maintainability out of 10, then a 2-sentence verdict
```

Why this works better than a direct prompt:
- The model cannot skip to a verdict without first inventorying every issue.
- Separating identification (Step 2) from classification (Step 3) reduces the chance of anchoring bias — the model notices more issues when it isn't simultaneously judging them.
- The user can see *where* the model's reasoning is strong or weak.

---

## Demo Snippets for Viva

| File | Bug type | Expected findings |
|---|---|---|
| `bug_python.py` | `eval()` RCE | Critical Security, Minor Style |
| `sqli_python.py` | SQL injection | Critical Security, Minor Style |
| `async_js.js` | Async/await misuse | Critical Bug, Major Security |
| `performance_python.py` | O(n³) algorithm | Major Performance, Minor Style ×2 |
| `antipattern_java.java` | 5 Java anti-patterns | Critical Bug, Major ×2, Minor ×2 |

---

## Prompting Technique Comparison (for CIA-2 / written exam)

| Aspect | Zero-Shot | Few-Shot | Chain-of-Thought |
|---|---|---|---|
| Prompt length | Short | Medium (+ 2 examples) | Long (structured steps) |
| Output consistency | Low | Medium | High |
| Reasoning visible | No | No | Yes — 5 explicit steps |
| Best for | Quick scan | Format calibration | Thorough, auditable reviews |
| Token cost | Lowest | Medium | Highest |
| Maps to syllabus | U2 | U3 | U3 (core CoT topic) |

**Key finding from testing these modes on `sqli_python.py`:**  
Zero-Shot identified the SQL injection but missed the missing `conn.close()`.  
Few-Shot caught both but gave a generic fix.  
CoT caught both, explained *why* parameterised queries prevent injection at the SQL parser level, and produced a complete corrected function.

---

## Extending the Project

- **Add Tree-of-Thought (ToT):** Generate 3 candidate reviews independently, then synthesise the best findings. Maps to U3 ToT topic.
- **Add Self-Consistency:** Run CoT 3 times and take a majority vote on severity labels. Maps to U3 self-consistency topic.
- **Add Gemini:** Swap OpenAI client for Google Generative AI SDK for a 3-way comparison. Maps to U5.
- **Extend Structured mode:** Use Claude's native tool-use (JSON schema enforcement) instead of prompting for JSON. Stronger CO4 coverage.

---

## References

- Anthropic Claude API: https://docs.anthropic.com
- OpenAI API: https://platform.openai.com/docs
- Wei et al. (2022) — *Chain-of-Thought Prompting Elicits Reasoning in Large Language Models*
- Brown et al. (2020) — *Language Models are Few-Shot Learners* (GPT-3 paper)
- Jurafsky & Martin — *Speech and Language Processing* (course textbook)

---

*IT742E06 Prompt Engineering · CHRIST (Deemed to be University) · Batch 2023–27*
