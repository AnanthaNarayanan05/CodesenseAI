"""
core/mock_data.py
-----------------
Mock review results for Offline Simulation Mode.
Defines pre-baked review responses for all 5 demo snippets in the 4 prompt modes.
"""

import json

# 1. PYTHON EVAL RCE
MOCK_EVAL_BUG = {
    "Zero-Shot": """Summary: This code evaluates arbitrary expressions from user input using the unsafe `eval()` function.

Issues:
1. Category: Security | Severity: Critical
   Problem: In L2, `eval(user_input)` executes arbitrary code in the context of the running application, resulting in Remote Code Execution (RCE).
   Fix: Use `ast.literal_eval` for safe evaluation of literal structures, or implement an operations whitelist.

2. Category: Style | Severity: Minor
   Problem: Code lacks type hints and relies on global scope inputs.
   Fix: Define a clean function wrapper with type annotations.

Verdict: Critically vulnerable. Do not deploy. Replace `eval()` immediately.""",

    "Few-Shot": """Summary: This snippet reads input from the terminal and runs it through `eval()` directly.

Issues:
1. Category: Security | Severity: Critical
   Problem: Use of `eval()` on unsanitized inputs allows an attacker to execute arbitrary system code.
   Fix: Rewrite to use `ast.literal_eval(user_input)` to restrict inputs to safe Python literal types only:
        ```python
        import ast
        result = ast.literal_eval(user_input)
        ```

2. Category: Style | Severity: Minor
   Problem: General variable names (`user_input`, `result`) are a bit too generic.
   Fix: Rename to `expression_str` and add type annotations.

Verdict: Unsafe. Use `ast.literal_eval` to prevent remote command execution.""",

    "Chain-of-Thought": """STEP 1 — UNDERSTAND
The code defines a `calculate` function that evaluates a string provided by the user using Python's built-in `eval` function. It is meant to act as a simple command-line calculator, but it runs whatever Python code the user types in.

STEP 2 — IDENTIFY
- L2: Use of `eval(user_input)` on untrusted user inputs.
- L5: Global scope input read without validation or exception handling.
- L1: Lacks parameter and return type annotations.

STEP 3 — CLASSIFY
- Issue 1: Security | Severity: Critical | L2
- Issue 2: Best Practice | Severity: Minor | L5
- Issue 3: Style | Severity: Minor | L1

STEP 4 — SUGGEST
a) Corrected code snippet:
```python
import ast

def calculate(user_input: str):
    try:
        # ast.literal_eval only parses strings containing python literals (strings, numbers, tuples, lists, dicts)
        return ast.literal_eval(user_input)
    except (ValueError, SyntaxError):
        return "Invalid Expression"
```
b) Using `ast.literal_eval` restricts evaluation to constants and basic Python literals rather than executing arbitrary compiled code blocks, blocking Remote Code Execution.

STEP 5 — SCORE AND SUMMARISE
- Correctness: 5
- Security: 1
- Readability: 8
- Efficiency: 9
- Maintainability: 7

Verdict: The script is highly dangerous due to potential remote code execution via `eval()`. Standardize on `ast.literal_eval` to secure it immediately.""",

    "Structured (JSON)": json.dumps({
        "language": "Python",
        "understanding": "Evaluates math expressions or statements entered by the user via terminal using Python's built-in eval function.",
        "findings": [
            {
                "line_ref": "L2",
                "category": "Security",
                "severity": "Critical",
                "description": "eval() on untrusted user inputs allows Remote Code Execution (RCE). An attacker can run system command loops (e.g. __import__('os').system('...')).",
                "fix_snippet": "import ast\nresult = ast.literal_eval(user_input)"
            },
            {
                "line_ref": "L5",
                "category": "Best Practice",
                "severity": "Minor",
                "description": "Direct shell-input reading without try/except handling makes the CLI fragile to EOF/Interrupt signals.",
                "fix_snippet": "try:\n    expr = input('Enter expression: ')\nexcept (KeyboardInterrupt, EOFError):\n    print('\\nExiting')\n    sys.exit(0)"
            }
        ],
        "scores": {
            "correctness": 5,
            "security": 1,
            "readability": 8,
            "efficiency": 9,
            "maintainability": 7
        },
        "refactored_code": "import ast\n\ndef calculate(user_input: str):\n    try:\n        # Safe evaluation of mathematical/literal structures\n        return ast.literal_eval(user_input)\n    except (ValueError, SyntaxError):\n        return None\n\nif __name__ == '__main__':\n    try:\n        expr = input('Enter expression: ')\n        print(calculate(expr))\n    except (KeyboardInterrupt, EOFError):\n        pass",
        "verdict": "Unsafe due to eval-based command execution. Upgrade to ast.literal_eval to eliminate the RCE security gap."
    })
}

# 2. PYTHON SQL INJECTION
MOCK_SQLI = {
    "Zero-Shot": """Summary: The function queries a SQLite database for a user using raw string concatenation to construct the SQL query.

Issues:
1. Category: Security | Severity: Critical
   Problem: In L6, constructing a SQL command using string concatenation allows SQL Injection attacks.
   Fix: Use parameterized SQL queries (placeholder bindings) rather than raw string concatenation.

2. Category: Best Practice | Severity: Minor
   Problem: In L4, the connection `conn` is opened but never closed, which can leak resource descriptors.
   Fix: Wrap in a context manager (`with sqlite3.connect(...) as conn:`) to ensure automatic closing.

Verdict: Unsafe. Use query parameters and context managers to avoid injection vulnerabilities and database leaks.""",

    "Few-Shot": """Summary: Retrieves user records from a SQLite database matching the supplied username parameter using dynamically built queries.

Issues:
1. Category: Security | Severity: Critical
   Problem: Concatenating `username` directly into the query string enables SQL Injection. Attackers can pass `' OR '1'='1` to access all users.
   Fix: Rewrite to bind parameters using placeholders:
        ```python
        query = "SELECT * FROM users WHERE name = ?"
        cursor.execute(query, (username,))
        ```

2. Category: Best Practice | Severity: Minor
   Problem: The database connection `conn` is left open.
   Fix: Close the connection before returning, or wrap the database workflow in a `with` statement.

Verdict: Vulnerable to SQL injection. Rewrite the script to use parameterized queries and close database resources properly.""",

    "Chain-of-Thought": """STEP 1 — UNDERSTAND
This function `get_user` queries a SQLite database for a matching username. The script opens a database connection, forms a query dynamically with string concatenation, executes it, and returns the result records.

STEP 2 — IDENTIFY
- L6: SQL query assembled via string concatenation (`"SELECT * ... '" + username + "'"`).
- L4: SQLite connection opened without clean closing mechanisms.
- L1: Connection setup inside the function causes expensive overhead on every single query call.

STEP 3 — CLASSIFY
- Issue 1: Security | Severity: Critical | L6
- Issue 2: Best Practice | Severity: Major | L4
- Issue 3: Performance | Severity: Minor | L4

STEP 4 — SUGGEST
a) Corrected code snippet:
```python
import sqlite3

def get_user(username: str):
    # Context manager automatically handles conn.close()
    with sqlite3.connect('users.db') as conn:
        cursor = conn.cursor()
        # Parameterized binding
        cursor.execute("SELECT * FROM users WHERE name = ?", (username,))
        return cursor.fetchall()
```
b) Placing `username` inside the execute call as a binding tuple forces the SQL database driver to treat it strictly as a parameter literal, neutralizing injection payload vectors.

STEP 5 — SCORE AND SUMMARISE
- Correctness: 6
- Security: 2
- Readability: 7
- Efficiency: 8
- Maintainability: 6

Verdict: Critically vulnerable to SQL injection. Parametrize query parameters immediately and manage connections using `with` blocks.""",

    "Structured (JSON)": json.dumps({
        "language": "Python",
        "understanding": "Queries a local SQLite database for a user matching a supplied username using dynamic string concatenation.",
        "findings": [
            {
                "line_ref": "L6",
                "category": "Security",
                "severity": "Critical",
                "description": "Constructing SQL queries using string concatenation enables SQL injection. Attackers can bypass authentication controls.",
                "fix_snippet": "cursor.execute(\"SELECT * FROM users WHERE name = ?\", (username,))"
            },
            {
                "line_ref": "L4",
                "category": "Best Practice",
                "severity": "Major",
                "description": "Database connection and cursors are not closed, which can cause connection leaks.",
                "fix_snippet": "with sqlite3.connect('users.db') as conn:\n    cursor = conn.cursor()\n    ..."
            }
        ],
        "scores": {
            "correctness": 6,
            "security": 2,
            "readability": 7,
            "efficiency": 8,
            "maintainability": 6
        },
        "refactored_code": "import sqlite3\n\ndef get_user(username: str):\n    \"\"\"Safely query user by username using parameterized inputs.\"\"\"\n    try:\n        with sqlite3.connect('users.db') as conn:\n            cursor = conn.cursor()\n            query = \"SELECT * FROM users WHERE name = ?\"\n            cursor.execute(query, (username,))\n            return cursor.fetchall()\n    except sqlite3.Error as e:\n        # Log error in production\n        return []",
        "verdict": "Vulnerable to SQL Injection. Parameterize parameters and wrap connection flows in context managers."
    })
}

# 3. JS ASYNC BUG
MOCK_JS_ASYNC = {
    "Zero-Shot": """Summary: The function performs an asynchronous API call to fetch a user profile, but returns a local variable synchronously before the fetch completes.

Issues:
1. Category: Bug | Severity: Critical
   Problem: In L6, `return profile` returns `undefined` synchronously because it executes before the `fetch` API response resolves.
   Fix: Make the function `async` and use `await` syntax.

2. Category: Security | Severity: Major
   Problem: No error handling on fetch requests (e.g. handling network failure or invalid response statuses).
   Fix: Wrap block in `try/catch` and verify `response.ok`.

Verdict: Completely non-functional code due to async mismatch. Apply `async/await` patterns to retrieve the user object correctly.""",

    "Few-Shot": """Summary: Fetches a user profile from the backend server by user ID and tries to return it to the caller.

Issues:
1. Category: Bug | Severity: Critical
   Problem: `fetch` runs asynchronously. The return statement runs before the callback assignments resolve, so it always returns `undefined`.
   Fix: Mark function as `async` and await the fetch and JSON parsing stages:
        ```javascript
        async function fetchUserProfile(userId) {
          const response = await fetch(`/api/users/${userId}`);
          return response.json();
        }
        ```

2. Category: Security | Severity: Major
   Problem: Missing error boundaries or HTTP status code check.
   Fix: Implement check on `response.ok` and handle catch rejections.

Verdict: Functional bug. The asynchronous flow is broken, resulting in constant undefined outputs.""",

    "Chain-of-Thought": """STEP 1 — UNDERSTAND
The function `fetchUserProfile` requests user data from `/api/users/:userId`. It invokes JavaScript's `fetch` API and assigns the parsed object to the inner `profile` variable, returning it to the caller.

STEP 2 — IDENTIFY
- L6: `return profile` executes synchronously before the fetch callbacks resolve.
- L3: Lacks checks on `response.ok` or HTTP codes.
- L3: No network error handling or `.catch` blocks.

STEP 3 — CLASSIFY
- Issue 1: Bug | Severity: Critical | L6
- Issue 2: Best Practice | Severity: Major | L3
- Issue 3: Security | Severity: Major | L3

STEP 4 — SUGGEST
a) Corrected code snippet:
```javascript
async function fetchUserProfile(userId) {
  try {
    const response = await fetch(`/api/users/${userId}`);
    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("Fetch profile failed:", error);
    throw error;
  }
}
```
b) Marking the outer function `async` permits the use of `await` inside the block, pausing execution until the network Promise is resolved.

STEP 5 — SCORE AND SUMMARISE
- Correctness: 1
- Security: 5
- Readability: 8
- Efficiency: 8
- Maintainability: 7

Verdict: The function is completely broken because it returns `undefined` before fetching data. Refactor with async/await and robust catch blocks.""",

    "Structured (JSON)": json.dumps({
        "language": "JavaScript",
        "understanding": "Asynchronously fetches a user profile JSON record from an API endpoint, returning the data value to callers.",
        "findings": [
            {
                "line_ref": "L6",
                "category": "Bug",
                "severity": "Critical",
                "description": "Return statement executes synchronously before asynchronous callbacks finish, rendering the return value undefined.",
                "fix_snippet": "async function fetchUserProfile(userId) {\n  const response = await fetch(`/api/users/${userId}`);\n  return response.json();\n}"
            },
            {
                "line_ref": "L3",
                "category": "Best Practice",
                "severity": "Major",
                "description": "Does not handle network connection losses or HTTP error status codes (e.g. 500 or 404).",
                "fix_snippet": "if (!response.ok) throw new Error('HTTP ' + response.status);"
            }
        ],
        "scores": {
            "correctness": 1,
            "security": 5,
            "readability": 8,
            "efficiency": 8,
            "maintainability": 7
        },
        "refactored_code": "async function fetchUserProfile(userId) {\n  try {\n    const response = await fetch(`/api/users/${userId}`);\n    if (!response.ok) {\n      throw new Error(`Network response error: ${response.status}`);\n    }\n    return await response.json();\n  } catch (error) {\n    console.error(`Failed fetching profile for user ${userId}:`, error);\n    throw error;\n  }\n}",
        "verdict": "Non-functional due to synchronous return of a variable populated inside async callbacks. Restructure using async/await."
    })
}

# 4. PYTHON O(N^3) PERFORMANCE
MOCK_O_N3 = {
    "Zero-Shot": """Summary: This function processes a list to identify duplicate values using nested loops and lists lookup operations.

Issues:
1. Category: Performance | Severity: Major
   Problem: In L3-L4, nesting two loops (`O(n^2)`) and combining them with `lst[i] not in duplicates` linear search results in `O(n^3)` runtime complexity.
   Fix: Optimize the search by tracking duplicates using a set for `O(n)` linear time complexity.

2. Category: Style | Severity: Minor
   Problem: Missing type hints on arguments and the return value.
   Fix: Annotate signature as `find_duplicates(lst: list) -> list`.

Verdict: Inefficient. The algorithm will choke on large lists. Refactor using set lookups to reach linear time performance.""",

    "Few-Shot": """Summary: Scans an input list for values that occur more than once, returning a list of unique duplicate elements.

Issues:
1. Category: Performance | Severity: Major
   Problem: Nested loops check element combinations, while list searches (`not in duplicates`) generate `O(n^3)` time complexity.
   Fix: Use tracking sets to check duplicates in a single pass:
        ```python
        seen = set()
        duplicates = set()
        for item in lst:
            if item in seen:
                duplicates.add(item)
            seen.add(item)
        return list(duplicates)
        ```

2. Category: Style | Severity: Minor
   Problem: Non-descriptive names and absent type annotations.
   Fix: Annotate input arguments and rename variables to follow Python styling guidelines.

Verdict: Poor performance. Using sets scales the complexity down to O(n) and speeds up list analysis significantly.""",

    "Chain-of-Thought": """STEP 1 — UNDERSTAND
The function `find_duplicates` takes a list and detects duplicates by comparing every element combination using nested iterators. It stores duplicates in a list, ensuring uniqueness via a list containment check.

STEP 2 — IDENTIFY
- L3-L4: Nested loops checking `i` against `j` runs in `O(n^2)` comparisons.
- L5: Checking membership inside the `duplicates` list (`not in duplicates`) runs in `O(n)` time, making total complexity `O(n^3)`.
- L1: Function has no parameter or output type hints.

STEP 3 — CLASSIFY
- Issue 1: Performance | Severity: Major | L3–L6
- Issue 2: Style | Severity: Minor | L1
- Issue 3: Style | Severity: Minor | L2

STEP 4 — SUGGEST
a) Corrected code snippet:
```python
def find_duplicates(lst: list) -> list:
    seen = set()
    duplicates = set()
    for item in lst:
        if item in seen:
            duplicates.add(item)
        else:
            seen.add(item)
    return list(duplicates)
```
b) Set insertions and searches average O(1) time complexity, reducing the performance runtime from cubic `O(n^3)` to linear `O(n)`.

STEP 5 — SCORE AND SUMMARISE
- Correctness: 8
- Security: 9
- Readability: 8
- Efficiency: 2
- Maintainability: 7

Verdict: The algorithm suffers from extreme cubic complexity. Restructure it using sets to resolve efficiency bottlenecks for large datasets.""",

    "Structured (JSON)": json.dumps({
        "language": "Python",
        "understanding": "Identifies duplicates in a list by checking every element pair through nested loops and checking unique values via list lookup.",
        "findings": [
            {
                "line_ref": "L3-L6",
                "category": "Performance",
                "severity": "Major",
                "description": "Double loop structures with list lookup results in cubic O(n^3) time complexity. Execution slows down on larger arrays.",
                "fix_snippet": "seen = set()\nduplicates = set()\nfor x in lst:\n    if x in seen:\n        duplicates.add(x)\n    seen.add(x)"
            },
            {
                "line_ref": "L1",
                "category": "Style",
                "severity": "Minor",
                "description": "Missing type annotations on function parameters and return signature.",
                "fix_snippet": "def find_duplicates(lst: list) -> list:"
            }
        ],
        "scores": {
            "correctness": 8,
            "security": 9,
            "readability": 8,
            "efficiency": 2,
            "maintainability": 7
        },
        "refactored_code": "def find_duplicates(lst: list) -> list:\n    \"\"\"Find duplicates in O(n) time using set tracking.\"\"\"\n    seen = set()\n    duplicates = set()\n    for item in lst:\n        if item in seen:\n            duplicates.add(item)\n        else:\n            seen.add(item)\n    return list(duplicates)",
        "verdict": "Inefficient cubic algorithm. Optimize using set membership to achieve linear O(n) time complexity."
    })
}

# 5. JAVA MULTIPLE ANTI-PATTERNS
MOCK_JAVA_ANTIPATTERN = {
    "Zero-Shot": """Summary: The `UserManager` class has multiple anti-patterns including reference-based string comparison, broad exception swallowing, and inefficient string concatenation in a loop.

Issues:
1. Category: Bug | Severity: Critical
   Problem: In L6, comparing strings using `name != ""` checks reference equality instead of value equality.
   Fix: Use `!name.equals("")` or `!name.isEmpty()`.

2. Category: Best Practice | Severity: Major
   Problem: In L9, a catch-all block handles `Exception` and silently swallows it, masking bugs.
   Fix: Log the exception or catch specific exceptions like `NullPointerException`.

3. Category: Performance | Severity: Major
   Problem: In L16, string concatenation in a loop creates multiple `String` objects, causing memory overhead.
   Fix: Use a `StringBuilder` to accumulate user list output.

Verdict: Poor quality. Code contains critical logic flaws, broad catch blocks, and memory leaks. Refactor with StringBuilders and value equality.""",

    "Few-Shot": """Summary: Provides service mechanisms to insert usernames to an internal collection array and print them as a single concatenated list.

Issues:
1. Category: Bug | Severity: Critical
   Problem: Comparing strings using `!=` checks object identity. This will fail to filter empty strings created dynamically.
   Fix: Change to use value comparison checks:
        ```java
        if (!"".equals(name))
        ```

2. Category: Best Practice | Severity: Major
   Problem: Empty catch block ignores errors completely.
   Fix: Log warnings or rethrow nested exceptions to catch bugs.

3. Category: Performance | Severity: Major
   Problem: Loop uses string addition (`result += user`), which allocates new strings in loop steps.
   Fix: Replace with `StringBuilder`:
        ```java
        StringBuilder sb = new StringBuilder();
        for (String user : users) { sb.append(user).append(", "); }
        ```

Verdict: Contains multiple runtime issues. Refactor to use StringBuilder loops, log exceptions, and use equals().""",

    "Chain-of-Thought": """STEP 1 — UNDERSTAND
The Java class `UserManager` implements methods to insert names into an list object and assemble them as a single comma-separated text string, displaying them in a simple report list.

STEP 2 — IDENTIFY
- L6: Reference comparison `name != ""` checks object memory addresses instead of string characters.
- L9: Catching raw `Exception` class is too generic.
- L10: Empty block swallows errors, masking potential bugs.
- L16: Inefficient loop string concatenation (`result += user`) creates multiple intermediate objects.
- L3: The inner list field `users` is public, exposing database mutable state directly to callers.

STEP 3 — CLASSIFY
- Issue 1: Bug | Severity: Critical | L6
- Issue 2: Best Practice | Severity: Major | L9-L10
- Issue 3: Performance | Severity: Major | L16
- Issue 4: Best Practice | Severity: Minor | L3

STEP 4 — SUGGEST
a) Corrected code snippet:
```java
import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private final List<String> users = new ArrayList<>();

    public synchronized void addUser(String name) {
        if (name != null && !name.trim().isEmpty()) {
            users.add(name);
        }
    }

    public String listUsers() {
        StringBuilder result = new StringBuilder();
        for (String user : users) {
            result.append(user).append(", ");
        }
        return result.toString();
    }
}
```
b) Using `StringBuilder` aggregates character segments inside a mutable internal buffer, eliminating dynamic class allocation overhead in the loops.

STEP 5 — SCORE AND SUMMARISE
- Correctness: 4
- Security: 7
- Readability: 6
- Efficiency: 4
- Maintainability: 5

Verdict: Critical bugs are present in object equality checks and empty catch blocks. Fix the string comparisons and loop iterations immediately.""",

    "Structured (JSON)": json.dumps({
        "language": "Java",
        "understanding": "Stores list values representing user entries and concatenates list contents into a single string formatting output.",
        "findings": [
            {
                "line_ref": "L6",
                "category": "Bug",
                "severity": "Critical",
                "description": "Using string identity check != instead of equals() logic checks object addresses, leading to incorrect evaluations.",
                "fix_snippet": "if (name != null && !name.equals(\"\"))"
            },
            {
                "line_ref": "L9-L10",
                "category": "Best Practice",
                "severity": "Major",
                "description": "Broad Exception interception with empty blocks swallows runtime errors and complicates stack trace analysis.",
                "fix_snippet": "} catch (NullPointerException e) {\n    logger.error(e);\n}"
            },
            {
                "line_ref": "L16",
                "category": "Performance",
                "severity": "Major",
                "description": "Dynamic string concatenation (+ operator) in loops allocates memory frames dynamically, lowering speed.",
                "fix_snippet": "StringBuilder sb = new StringBuilder();\nsb.append(user);"
            }
        ],
        "scores": {
            "correctness": 4,
            "security": 7,
            "readability": 6,
            "efficiency": 4,
            "maintainability": 5
        },
        "refactored_code": "import java.util.ArrayList;\nimport java.util.List;\nimport java.util.Collections;\n\npublic class UserManager {\n    private final List<String> users = new ArrayList<>();\n\n    public void addUser(String name) {\n        if (name == null || name.trim().isEmpty()) {\n            return;\n        }\n        users.add(name);\n    }\n\n    public String listUsers() {\n        StringBuilder result = new StringBuilder();\n        for (String user : users) {\n            result.append(user).append(\", \");\n        }\n        return result.toString();\n    }\n\n    public List<String> getUsers() {\n        return Collections.unmodifiableList(users);\n    }\n}",
        "verdict": "Contains structural errors. Replace reference checks with .equals(), implement StringBuilder loops, and handle exceptions."
    })
}

# 6. FALLBACK MOCK DATA
MOCK_FALLBACK = {
    "Zero-Shot": """Summary: User submitted code review analysis.

Issues:
1. Category: Best Practice | Severity: Minor
   Problem: Code contains generic formatting patterns.
   Fix: Structure functions and classes cleanly with explicit configurations.

Verdict: Code appears structure-compliant, but standard tests and validation are recommended.""",

    "Few-Shot": """Summary: Evaluates user code snippets.

Issues:
1. Category: Best Practice | Severity: Minor
   Problem: Lacks parameter verification and strict checks.
   Fix: Add conditional guards to prevent null/empty references.

Verdict: Review complete. Ensure you implement unit tests to cover logical exceptions.""",

    "Chain-of-Thought": """STEP 1 — UNDERSTAND
This is a user-submitted code block. The system analyzes this structure to detect syntax errors, structural anomalies, or logic defects.

STEP 2 — IDENTIFY
- L1: General check of variable names.
- L2: Broad loop or evaluation blocks.

STEP 3 — CLASSIFY
- Issue 1: Best Practice | Severity: Minor | L1

STEP 4 — SUGGEST
a) Corrected code snippet:
```python
# General recommended pattern
def process_data(data):
    if not data:
        return []
    return [x for x in data if x is not None]
```
b) Guard clauses prevent secondary functions from failing when passed empty arguments.

STEP 5 — SCORE AND SUMMARISE
- Correctness: 7
- Security: 8
- Readability: 8
- Efficiency: 7
- Maintainability: 7

Verdict: The code shows basic compliance. Ensure proper parameter validation is set up.""",

    "Structured (JSON)": json.dumps({
        "language": "Other",
        "understanding": "General user-submitted logic snippet for automated code quality audit review.",
        "findings": [
            {
                "line_ref": "global",
                "category": "Best Practice",
                "severity": "Minor",
                "description": "Code does not show explicit guard clauses or input validation checks.",
                "fix_snippet": ""
            }
        ],
        "scores": {
            "correctness": 7,
            "security": 8,
            "readability": 8,
            "efficiency": 7,
            "maintainability": 7
        },
        "refactored_code": "",
        "verdict": "General analysis complete. Add unit checks to guarantee compliance."
    })
}


def get_mock_review(code: str, language: str, mode_name: str, provider: str = "Claude") -> str:
    """
    Returns mock review response text (or JSON string) based on the code contents and mode.
    """
    code_lower = code.lower()
    
    # Select dataset
    if "eval(user_input)" in code_lower:
        dataset = MOCK_EVAL_BUG
    elif "select * from users where name" in code_lower or "name = '" in code_lower:
        dataset = MOCK_SQLI
    elif "fetchuserprofile" in code_lower:
        dataset = MOCK_JS_ASYNC
    elif "find_duplicates" in code_lower:
        dataset = MOCK_O_N3
    elif "class usermanager" in code_lower:
        dataset = MOCK_JAVA_ANTIPATTERN
    else:
        dataset = MOCK_FALLBACK

    review_text = dataset.get(mode_name, dataset["Chain-of-Thought"])
    
    # Customise text slightly if provider is GPT-4o to make comparison obvious
    if provider == "GPT" and mode_name != "Structured (JSON)":
        review_text = f"[GPT-4o Simulation Output]\n\n" + review_text
        
    return review_text
