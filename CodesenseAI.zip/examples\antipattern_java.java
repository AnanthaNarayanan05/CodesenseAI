// examples/antipattern_java.java
// Demo 5: Java — multiple anti-patterns (Major + Minor issues)

import java.util.*;

public class UserManager {
    
    // L7: Major — public mutable field, breaks encapsulation
    public List<String> users = new ArrayList<>();
    
    // L10: Major — catches Exception (too broad), swallows error silently
    public void addUser(String name) {
        try {
            if (name != "") {              // L12: Bug — string comparison with !=
                users.add(name);
            }
        } catch (Exception e) {           // L15: swallows ALL exceptions silently
            // do nothing
        }
    }
    
    // L20: Performance/Minor — concatenating strings in a loop (O(n²) memory)
    public String listUsers() {
        String result = "";
        for (String user : users) {
            result += user + ", ";         // L23: use StringBuilder
        }
        return result;
    }
    
    // L27: Style — magic number, no constant defined
    public boolean isMaxCapacity() {
        return users.size() >= 100;        // L29: extract to static final MAX_USERS
    }
}

// Issues summary:
// 1. Bug/Critical:       String comparison with != instead of .equals()
// 2. Best Practice/Major: public mutable field — should be private with getter
// 3. Bug/Major:          Catching Exception instead of specific exceptions
// 4. Performance/Minor:  String concatenation in loop — use StringBuilder
// 5. Style/Info:         Magic number 100 should be a named constant
