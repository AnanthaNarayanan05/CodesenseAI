"""
openai_client.py
----------------
OpenAI GPT-4o wrapper for CodeSense model comparison mode.

Mirrors the ClaudeReviewer interface so the compare_panel component
can call both clients identically and diff their outputs.

Used for: U5 — Model-Specific Optimization / "Compare outputs of
different LLMs for the same prompt" (Practical Experiment 1, Unit 5).
"""

import time
import openai
from openai import OpenAI

from core.prompts import PromptMode, get_prompt
from core.claude_client import ReviewResult, Finding, Scores, _parse_text_response
from core.mock_data import get_mock_review


class GPTReviewer:
    """
    Wraps the OpenAI Chat Completions API for code review.

    Uses the same prompt templates as ClaudeReviewer so the comparison
    is purely about model behaviour, not prompt differences.

    Usage:
        reviewer = GPTReviewer(api_key="sk-...")
        result = reviewer.review(code, language, PromptMode.COT)
    """

    MODEL = "gpt-4o-mini"      # Swap to "gpt-4o" for higher quality
    MAX_TOKENS = 2048

    def __init__(self, api_key: str):
        if not api_key or not api_key.startswith("sk-"):
            raise ValueError(
                "Invalid OpenAI API key. "
                "It should start with 'sk-'. "
                "Get yours at https://platform.openai.com/api-keys"
            )
        self.api_key = api_key
        if not self.is_mock():
            self.client = OpenAI(api_key=api_key)

    def is_mock(self) -> bool:
        return "mock" in self.api_key.lower()

    def review(
        self,
        code: str,
        language: str,
        mode: PromptMode = PromptMode.COT,
    ) -> ReviewResult:
        """
        Blocking (non-streaming) review via OpenAI Chat Completions.

        Returns a ReviewResult with the same structure as ClaudeReviewer
        so the UI can render both results identically.
        """
        if self.is_mock():
            start_ms = _now_ms()
            time.sleep(0.3)
            raw = get_mock_review(code, language, mode.value, "GPT")
            result = ReviewResult(
                mode=mode,
                language=language,
                raw_response=raw,
                input_tokens=150,
                output_tokens=300,
                latency_ms=_now_ms() - start_ms,
            )
            _parse_text_response(result, raw, mode)
            return result

        system, user_fn = get_prompt(mode)
        user_msg = user_fn(code=code, language=language)

        start_ms = _now_ms()

        try:
            response = self.client.chat.completions.create(
                model=self.MODEL,
                max_tokens=self.MAX_TOKENS,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user_msg},
                ],
            )
        except openai.AuthenticationError:
            raise ValueError(
                "OpenAI authentication failed. Check your API key."
            )
        except openai.RateLimitError:
            raise RuntimeError(
                "OpenAI rate limit reached. Wait a moment and try again."
            )
        except openai.APIError as e:
            raise RuntimeError(f"OpenAI API error: {e}")

        raw = response.choices[0].message.content.strip()

        result = ReviewResult(
            mode=mode,
            language=language,
            raw_response=raw,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
            latency_ms=_now_ms() - start_ms,
        )

        _parse_text_response(result, raw, mode)
        return result

    def stream_review(self, code: str, language: str, mode: PromptMode):
        """
        Streaming version — yields text chunks for live Streamlit display.

        Usage mirrors ClaudeReviewer.stream_review().
        """
        if self.is_mock():
            mock_text = get_mock_review(code, language, mode.value, "GPT")
            words = mock_text.split(" ")
            full_text = ""
            start_ms = _now_ms()
            for i, word in enumerate(words):
                chunk = word + (" " if i < len(words) - 1 else "")
                full_text += chunk
                yield chunk
                time.sleep(0.01)
            result = ReviewResult(
                mode=mode,
                language=language,
                raw_response=full_text,
                latency_ms=_now_ms() - start_ms,
            )
            _parse_text_response(result, full_text, mode)
            return result

        system, user_fn = get_prompt(mode)
        user_msg = user_fn(code=code, language=language)

        full_text = ""
        start_ms = _now_ms()

        try:
            stream = self.client.chat.completions.create(
                model=self.MODEL,
                max_tokens=self.MAX_TOKENS,
                stream=True,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user_msg},
                ],
            )
            for chunk in stream:
                delta = chunk.choices[0].delta
                if delta.content:
                    full_text += delta.content
                    yield delta.content

        except openai.AuthenticationError:
            raise ValueError("OpenAI authentication failed.")
        except openai.RateLimitError:
            raise RuntimeError("OpenAI rate limit reached.")
        except openai.APIError as e:
            raise RuntimeError(f"OpenAI API error: {e}")

        result = ReviewResult(
            mode=mode,
            language=language,
            raw_response=full_text,
            latency_ms=_now_ms() - start_ms,
        )
        _parse_text_response(result, full_text, mode)
        return result


def _now_ms() -> int:
    return int(time.time() * 1000)
