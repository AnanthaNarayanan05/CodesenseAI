// examples/async_js.js
// Demo 3: JavaScript — async/await misuse (Critical Bug)

function fetchUserProfile(userId) {
  let profile;                          // L4: always undefined on return
  fetch(`/api/users/${userId}`)
    .then(response => response.json())
    .then(data => {
      profile = data;                   // L8: assigned AFTER function returns
    });
  return profile;                       // L10: returns undefined every time
}

// Also missing: error handling for network failures, HTTP error status checks
// Also: no input validation on userId (open redirect / SSRF risk)
const user = fetchUserProfile(42);
console.log(user.name);  // TypeError: Cannot read properties of undefined
