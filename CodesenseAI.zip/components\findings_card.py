"""
components/findings_card.py
---------------------------
Renders the categorised findings panel for CodeSense.

Each finding is displayed as a Streamlit expander card with:
  - Severity icon + colour badge
  - Category icon
  - Line reference
  - Description
  - Fix code snippet (if available)

Usage:
    from components.findings_card import render_findings
    render_findings(result)
"""

import streamlit as st
from core.claude_client import ReviewResult, Finding, sort_findings


# ── Display maps ───────────────────────────────────────────────

SEVERITY_CONFIG = {
    "Critical": {"icon": "🔴", "colour": "#EF4444", "bg": "#FEF2F2"},
    "Major":    {"icon": "🟠", "colour": "#F59E0B", "bg": "#FFFBEB"},
    "Minor":    {"icon": "🟡", "colour": "#EAB308", "bg": "#FEFCE8"},
    "Info":     {"icon": "🔵", "colour": "#3B82F6", "bg": "#EFF6FF"},
}

CATEGORY_CONFIG = {
    "Bug":           {"icon": "🐛", "label": "Bug"},
    "Security":      {"icon": "🔒", "label": "Security"},
    "Performance":   {"icon": "⚡", "label": "Performance"},
    "Style":         {"icon": "🎨", "label": "Style"},
    "Best Practice": {"icon": "📘", "label": "Best Practice"},
}

SEVERITY_ORDER = ["Critical", "Major", "Minor", "Info"]


def render_findings(result: ReviewResult) -> None:
    """
    Renders all findings from a ReviewResult, grouped by severity.
    """
    findings = result.findings

    if not findings:
        st.success("✅ No structured findings extracted. Check the raw CoT output above.")
        return

    sorted_findings = sort_findings(findings)

    # ── Summary pills row ──────────────────────────────────────
    _render_severity_summary(findings)

    st.subheader(f"🐛 Findings ({len(findings)})")

    # ── Findings grouped by severity ───────────────────────────
    for severity in SEVERITY_ORDER:
        group = [f for f in sorted_findings if f.severity == severity]
        if not group:
            continue

        cfg = SEVERITY_CONFIG.get(severity, SEVERITY_CONFIG["Info"])
        st.markdown(
            f"<div style='font-size:13px;font-weight:600;"
            f"color:{cfg['colour']};margin:12px 0 6px'>"
            f"{cfg['icon']} {severity} ({len(group)})"
            f"</div>",
            unsafe_allow_html=True,
        )

        for finding in group:
            _render_finding_card(finding, result.language)


def render_findings_compact(findings: list[Finding], language: str) -> None:
    """
    Compact version — no grouping headers, used inside comparison columns.
    """
    if not findings:
        st.caption("No structured findings.")
        return

    for f in sort_findings(findings):
        _render_finding_card(f, language)


def _render_finding_card(finding: Finding, language: str) -> None:
    """Renders a single finding as a Streamlit expander."""
    sev_cfg = SEVERITY_CONFIG.get(finding.severity, SEVERITY_CONFIG["Info"])
    cat_cfg = CATEGORY_CONFIG.get(finding.category, {"icon": "📌", "label": finding.category})

    label = (
        f"{sev_cfg['icon']} {finding.severity}  ·  "
        f"{cat_cfg['icon']} {cat_cfg['label']}  ·  "
        f"`{finding.line_ref}`"
    )

    # Critical findings default to expanded
    default_open = finding.severity == "Critical"

    with st.expander(label, expanded=default_open):
        st.markdown(finding.description)
        if finding.fix_snippet and finding.fix_snippet.strip():
            st.markdown("**Suggested fix:**")
            st.code(finding.fix_snippet, language=language.lower())


def _render_severity_summary(findings: list[Finding]) -> None:
    """
    Renders a compact summary row showing count per severity.
    """
    counts = {sev: 0 for sev in SEVERITY_ORDER}
    for f in findings:
        if f.severity in counts:
            counts[f.severity] += 1

    cols = st.columns(4)
    for col, severity in zip(cols, SEVERITY_ORDER):
        cfg = SEVERITY_CONFIG[severity]
        count = counts[severity]
        col.markdown(
            f"<div style='"
            f"background:{cfg['bg']};border:1px solid {cfg['colour']}33;"
            f"border-radius:8px;padding:6px 0;text-align:center'>"
            f"<div style='font-size:18px'>{cfg['icon']}</div>"
            f"<div style='font-size:13px;font-weight:600;color:{cfg['colour']}'>{count}</div>"
            f"<div style='font-size:10px;color:#6B7280'>{severity}</div>"
            f"</div>",
            unsafe_allow_html=True,
        )
    st.markdown("<div style='margin-bottom:12px'></div>", unsafe_allow_html=True)
