"""
components/compare_panel.py
---------------------------
Side-by-side Claude vs GPT-4o comparison panel for CodeSense.

Maps to: IT742E06 Unit 5 — Model-Specific Optimization
Practical Experiment 1: "Compare outputs of different LLMs for the same prompt"
Course Outcome: CO5 — Inspect prompts for specific AI models

Usage:
    from components.compare_panel import render_comparison
    render_comparison(claude_result, gpt_result)
"""

import streamlit as st
import matplotlib.pyplot as plt
from core.claude_client import ReviewResult, Scores
from components.findings_card import render_findings_compact
from components.cot_viewer import render_cot_mini
from components.radar_chart import render_comparison_chart


def render_comparison(
    claude_result: ReviewResult,
    gpt_result: ReviewResult,
) -> None:
    """
    Renders the full side-by-side comparison of Claude and GPT-4o results.

    Layout:
      [Metrics row — latency, tokens, avg score]
      [Overlap analysis — what both models agreed on]
      [Radar chart — overlaid scores]
      [Left: Claude findings]  [Right: GPT-4o findings]
      [CoT chains side by side if mode == COT]
    """
    st.subheader("🆚 Model Comparison — Claude vs GPT-4o")
    st.caption(
        "Same code · Same prompt · Same mode · Different models. "
        "This panel covers CO5 (model-specific optimization)."
    )

    # ── Top metrics row ────────────────────────────────────────
    _render_metrics_row(claude_result, gpt_result)

    st.divider()

    # ── Overlap analysis ───────────────────────────────────────
    _render_overlap_analysis(claude_result, gpt_result)

    st.divider()

    # ── Radar chart ────────────────────────────────────────────
    if claude_result.scores.average() > 0 and gpt_result.scores.average() > 0:
        fig = render_comparison_chart(claude_result.scores, gpt_result.scores)
        st.pyplot(fig)
        plt.close(fig)
        st.divider()

    # ── Side-by-side findings ──────────────────────────────────
    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown("#### 🟣 Claude Findings")
        render_findings_compact(claude_result.findings, claude_result.language)
        if claude_result.verdict:
            st.info(f"**Verdict:** {claude_result.verdict}")

    with col_right:
        st.markdown("#### 🟢 GPT-4o Findings")
        render_findings_compact(gpt_result.findings, gpt_result.language)
        if gpt_result.verdict:
            st.info(f"**Verdict:** {gpt_result.verdict}")

    # ── CoT chains (if applicable) ─────────────────────────────
    from core.prompts import PromptMode
    if claude_result.mode == PromptMode.COT:
        st.divider()
        st.subheader("🔗 Chain-of-Thought — Side by Side")
        col_cot_l, col_cot_r = st.columns(2)
        with col_cot_l:
            st.markdown("**Claude reasoning**")
            render_cot_mini(claude_result)
        with col_cot_r:
            st.markdown("**GPT-4o reasoning**")
            render_cot_mini(gpt_result)


def _render_metrics_row(
    claude: ReviewResult,
    gpt: ReviewResult,
) -> None:
    """Top row: latency, token usage, avg score, finding counts."""
    cols = st.columns(6)

    def _delta(a: float, b: float, lower_is_better: bool = False) -> str:
        diff = round(a - b, 1)
        if diff == 0:
            return "tied"
        better = diff > 0
        if lower_is_better:
            better = not better
        arrow = "↑" if better else "↓"
        return f"{arrow} {abs(diff)}"

    metrics = [
        ("Avg Score",    f"{claude.scores.average()}/10", f"{gpt.scores.average()}/10"),
        ("Findings",     len(claude.findings),            len(gpt.findings)),
        ("Critical",     claude.critical_count,           gpt.critical_count),
        ("Latency (ms)", claude.latency_ms,               gpt.latency_ms),
        ("In tokens",    claude.input_tokens,             gpt.input_tokens),
        ("Out tokens",   claude.output_tokens,            gpt.output_tokens),
    ]

    labels = ["", "🟣 Claude", "🟢 GPT-4o", "🟣 Claude", "🟢 GPT-4o", ""]

    # Simple 3-column table
    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("🟣 Avg Score",    f"{claude.scores.average()}/10")
        st.metric("🟣 Latency",      f"{claude.latency_ms} ms")
    with c2:
        st.metric("🟢 Avg Score",    f"{gpt.scores.average()}/10")
        st.metric("🟢 Latency",      f"{gpt.latency_ms} ms")
    with c3:
        st.metric("🟣 Findings",     len(claude.findings))
        st.metric("🟢 Findings",     len(gpt.findings))


def _render_overlap_analysis(
    claude: ReviewResult,
    gpt: ReviewResult,
) -> None:
    """
    Identifies findings both models agreed on (by category + severity)
    vs findings unique to each model.

    This is the analytical core of the U5 comparison feature.
    """
    st.subheader("🔍 Overlap Analysis")
    st.caption("Findings both models identified vs model-specific findings.")

    def _key(f):
        return f"{f.category}::{f.severity}"

    claude_keys = {_key(f) for f in claude.findings}
    gpt_keys    = {_key(f) for f in gpt.findings}

    shared       = claude_keys & gpt_keys
    only_claude  = claude_keys - gpt_keys
    only_gpt     = gpt_keys - claude_keys

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown(f"**✅ Both agreed ({len(shared)})**")
        if shared:
            for k in sorted(shared):
                cat, sev = k.split("::")
                st.markdown(f"- {sev} · {cat}")
        else:
            st.caption("No overlapping findings.")

    with col2:
        st.markdown(f"**🟣 Only Claude ({len(only_claude)})**")
        if only_claude:
            for k in sorted(only_claude):
                cat, sev = k.split("::")
                st.markdown(f"- {sev} · {cat}")
        else:
            st.caption("None unique to Claude.")

    with col3:
        st.markdown(f"**🟢 Only GPT-4o ({len(only_gpt)})**")
        if only_gpt:
            for k in sorted(only_gpt):
                cat, sev = k.split("::")
                st.markdown(f"- {sev} · {cat}")
        else:
            st.caption("None unique to GPT-4o.")

    agreement_pct = (
        round(len(shared) / len(claude_keys | gpt_keys) * 100)
        if (claude_keys | gpt_keys) else 0
    )
    st.progress(agreement_pct / 100,
                text=f"Agreement rate: {agreement_pct}%")
