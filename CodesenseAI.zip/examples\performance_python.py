# examples/performance_python.py
# Demo 4: Python — O(n²) algorithm with multiple style issues

def find_duplicates(lst):
    duplicates = []
    for i in range(len(lst)):           # L4: use enumerate() or iterate directly
        for j in range(len(lst)):       # L5: O(n²) — inner loop unnecessary
            if i != j and lst[i] == lst[j]:
                if lst[i] not in duplicates:   # L7: O(n) search inside O(n²) = O(n³)
                    duplicates.append(lst[i])
    return duplicates

# Issues:
# 1. Performance/Major: O(n³) overall — use set() for O(n)
# 2. Style/Minor:       range(len(lst)) anti-pattern
# 3. Best Practice/Info: no type hints, no docstring
# 4. Style/Minor:       variable name 'lst' shadows builtin 'list'

# Correct O(n) solution:
# def find_duplicates(items: list) -> list:
#     seen = set()
#     return [x for x in items if x in seen or seen.add(x)]

test = [1, 2, 3, 2, 4, 3, 5]
print(find_duplicates(test))
