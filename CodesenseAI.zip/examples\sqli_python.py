# examples/sqli_python.py
# Demo 2: SQL Injection via string concatenation (Critical Security)

import sqlite3

def get_user_by_name(username):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    # L6: CRITICAL — SQL injection via string concatenation
    query = "SELECT * FROM users WHERE name = '" + username + "'"
    cursor.execute(query)
    return cursor.fetchall()
    # Also missing: conn.close(), parameterised queries, error handling

# Attacker input: ' OR '1'='1 — returns ALL users
# Attacker input: '; DROP TABLE users; -- — destroys the table
result = get_user_by_name(input("Username: "))
print(result)
