"""
components/history_panel.py
---------------------------
Session-level review history panel for CodeSense.

Stores each review run during the session in Streamlit's session_state
and renders a sortable, filterable history table in the sidebar.

Usage:
    from components.history_panel import add_to_history, render_history_sidebar
    from core.claude_client import ReviewResult

    # After a review completes:
    add_to_history(result, code_snippet)

    # In the sidebar:
    render_history_sidebar()
"""

import streamlit as st
from datetime import datetime
from core.claude_client import ReviewResult


HISTORY_KEY = "codesense_history"


def add_to_history(result: ReviewResult, code_snippet: str) -> None:
    """
    Adds a completed ReviewResult to the session history.
    Called after every successful review run.
    """
    if HISTORY_KEY not in st.session_state:
        st.session_state[HISTORY_KEY] = []

    entry = {
        "timestamp":   datetime.now().strftime("%H:%M:%S"),
        "language":    result.language,
        "mode":        result.mode.value,
        "avg_score":   result.scores.average(),
        "n_findings":  len(result.findings),
        "critical":    result.critical_count,
        "major":       result.major_count,
        "latency_ms":  result.latency_ms,
        "in_tokens":   result.input_tokens,
        "out_tokens":  result.output_tokens,
        "verdict":     result.verdict[:120] + "…" if len(result.verdict) > 120 else result.verdict,
        "code_preview": code_snippet[:80] + "…" if len(code_snippet) > 80 else code_snippet,
    }

    st.session_state[HISTORY_KEY].insert(0, entry)   # newest first


def render_history_sidebar() -> None:
    """
    Renders the review history list in the Streamlit sidebar.
    Shows the last 10 reviews with key metrics.
    """
    history = st.session_state.get(HISTORY_KEY, [])

    st.subheader(f"📋 Review history ({len(history)})")

    if not history:
        st.caption("No reviews yet this session.")
        return

    # Clear button
    if st.button("🗑️ Clear history", use_container_width=True):
        st.session_state[HISTORY_KEY] = []
        st.rerun()

    for i, entry in enumerate(history[:10]):
        score = entry["avg_score"]
        score_icon = "🟢" if score >= 7 else "🟡" if score >= 4 else "🔴"
        crit = entry["critical"]
        crit_str = f" · 🔴{crit} crit" if crit > 0 else ""

        with st.expander(
            f"#{len(history) - i}  {entry['language']} · {entry['mode']} · {score_icon}{score}/10{crit_str}",
            expanded=False,
        ):
            st.caption(f"⏱ {entry['timestamp']}  ·  {entry['latency_ms']}ms  ·  "
                       f"{entry['in_tokens']+entry['out_tokens']} tokens")
            st.caption(f"Findings: {entry['n_findings']} total · "
                       f"{entry['critical']} critical · {entry['major']} major")
            if entry["verdict"]:
                st.markdown(f"*{entry['verdict']}*")
            st.code(entry["code_preview"], language=entry["language"].lower())


def render_history_main() -> None:
    """
    Full history table for the main panel — used if the user clicks
    a 'View full history' button. Renders a pandas DataFrame.
    """
    import pandas as pd

    history = st.session_state.get(HISTORY_KEY, [])
    if not history:
        st.info("No reviews yet this session.")
        return

    df = pd.DataFrame(history)[
        ["timestamp", "language", "mode", "avg_score",
         "n_findings", "critical", "major", "latency_ms"]
    ].rename(columns={
        "timestamp":  "Time",
        "language":   "Language",
        "mode":       "Mode",
        "avg_score":  "Avg Score",
        "n_findings": "Findings",
        "critical":   "Critical",
        "major":      "Major",
        "latency_ms": "Latency (ms)",
    })

    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Avg Score": st.column_config.ProgressColumn(
                "Avg Score", min_value=0, max_value=10, format="%.1f"
            ),
            "Critical": st.column_config.NumberColumn("🔴 Critical"),
            "Major":    st.column_config.NumberColumn("🟠 Major"),
        },
    )
