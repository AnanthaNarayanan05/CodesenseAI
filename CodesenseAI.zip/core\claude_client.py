"""
claude_client.py
----------------
Anthropic API wrapper for CodeSense.

Handles:
  - Streaming responses (yields text chunks for live UI updates)
  - Non-streaming responses (for structured JSON mode)
  - Response parsing into ReviewResult dataclass
  - Basic error handling with user-friendly messages

Model used: claude-haiku-4-5-20251001
(fast and cost-effective for code review; swap to claude-sonnet-4-6
 for higher quality if budget allows)
"""

import json
import time
import anthropic
from dataclasses import dataclass, field
from typing import Generator

from core.prompts import PromptMode, get_prompt
from core.mock_data import get_mock_review


# ─────────────────────────────────────────────────────────────
# DATA CLASSES
# ─────────────────────────────────────────────────────────────

@dataclass
class Finding:
    line_ref:    str
    category:    str   # Bug | Security | Performance | Style | Best Practice
    severity:    str   # Critical | Major | Minor | Info
    description: str
    fix_snippet: str = ""


@dataclass
class Scores:
    correctness:     int = 0
    security:        int = 0
    readability:     int = 0
    efficiency:      int = 0
    maintainability: int = 0

    def average(self) -> float:
        vals = [self.correctness, self.security,
                self.readability, self.efficiency, self.maintainability]
        return round(sum(vals) / len(vals), 1)


@dataclass
class ReviewResult:
    mode:            PromptMode
    language:        str
    raw_response:    str           # Full model output (shown in Prompt Inspector)
    understanding:   str = ""
    findings:        list[Finding] = field(default_factory=list)
    scores:          Scores        = field(default_factory=Scores)
    refactored_code: str = ""
    verdict:         str = ""
    input_tokens:    int = 0
    output_tokens:   int = 0
    latency_ms:      int = 0

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "Critical")

    @property
    def major_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "Major")

    @property
    def severity_color(self) -> str:
        """Returns a Streamlit color string based on worst severity found."""
        if self.critical_count > 0:
            return "red"
        if self.major_count > 0:
            return "orange"
        return "green"


# ─────────────────────────────────────────────────────────────
# CLIENT
# ─────────────────────────────────────────────────────────────

class ClaudeReviewer:
    """
    Wraps the Anthropic Messages API for code review.

    Usage:
        reviewer = ClaudeReviewer(api_key="sk-ant-...")
        
        # Streaming (for CoT / ZeroShot / FewShot — shows reasoning live)
        for chunk in reviewer.stream_review(code, language, PromptMode.COT):
            print(chunk, end="", flush=True)

        # Non-streaming (for Structured mode — parse JSON after full response)
        result = reviewer.review(code, language, PromptMode.STRUCTURED)
    """

    MODEL = "claude-haiku-4-5-20251001"
    MAX_TOKENS = 2048

    def __init__(self, api_key: str):
        if not api_key or not api_key.startswith("sk-ant-"):
            raise ValueError(
                "Invalid Anthropic API key. "
                "It should start with 'sk-ant-'. "
                "Get yours at https://console.anthropic.com/"
            )
        self.api_key = api_key
        if not self.is_mock():
            self.client = anthropic.Anthropic(api_key=api_key)

    def is_mock(self) -> bool:
        return "mock" in self.api_key.lower()

    # ── streaming ──────────────────────────────────────────────

    def stream_review(
        self,
        code: str,
        language: str,
        mode: PromptMode,
    ) -> Generator[str, None, ReviewResult]:
        """
        Streams the model response token-by-token.

        Yields:
            str — each text chunk as it arrives (for live Streamlit display)

        Returns (via StopIteration value):
            ReviewResult — the full parsed result after streaming completes

        Streamlit usage:
            placeholder = st.empty()
            full_text = ""
            gen = reviewer.stream_review(code, language, mode)
            try:
                while True:
                    chunk = next(gen)
                    full_text += chunk
                    placeholder.markdown(full_text)
            except StopIteration as e:
                result = e.value   # ReviewResult
        """
        if self.is_mock():
            mock_text = get_mock_review(code, language, mode.value, "Claude")
            words = mock_text.split(" ")
            full_text = ""
            start_ms = _now_ms()
            for i, word in enumerate(words):
                chunk = word + (" " if i < len(words) - 1 else "")
                full_text += chunk
                yield chunk
                time.sleep(0.01)  # Realistic typing delay
            result = ReviewResult(
                mode=mode,
                language=language,
                raw_response=full_text,
                input_tokens=120,
                output_tokens=len(words) * 2,
                latency_ms=_now_ms() - start_ms,
            )
            if mode != PromptMode.STRUCTURED:
                _parse_text_response(result, full_text, mode)
            return result

        system, user_fn = get_prompt(mode)
        user_msg = user_fn(code=code, language=language)

        full_text = ""
        input_tokens = 0
        output_tokens = 0
        start_ms = _now_ms()

        try:
            with self.client.messages.stream(
                model=self.MODEL,
                max_tokens=self.MAX_TOKENS,
                system=system,
                messages=[{"role": "user", "content": user_msg}],
            ) as stream:
                for text in stream.text_stream:
                    full_text += text
                    yield text

                # After stream closes, collect usage stats
                final_msg = stream.get_final_message()
                input_tokens  = final_msg.usage.input_tokens
                output_tokens = final_msg.usage.output_tokens

        except anthropic.AuthenticationError:
            raise ValueError(
                "Authentication failed. Check your Anthropic API key."
            )
        except anthropic.RateLimitError:
            raise RuntimeError(
                "Rate limit reached. Wait a moment and try again."
            )
        except anthropic.APIError as e:
            raise RuntimeError(f"Anthropic API error: {e}")

        result = ReviewResult(
            mode=mode,
            language=language,
            raw_response=full_text,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=_now_ms() - start_ms,
        )

        # Parse text response into structured fields for non-JSON modes
        if mode != PromptMode.STRUCTURED:
            _parse_text_response(result, full_text, mode)

        return result

    # ── non-streaming (structured JSON mode) ──────────────────

    def review(
        self,
        code: str,
        language: str,
        mode: PromptMode = PromptMode.STRUCTURED,
    ) -> ReviewResult:
        """
        Blocking API call — used for Structured (JSON) mode where
        we need the full response before we can parse it.
        """
        if self.is_mock():
            start_ms = _now_ms()
            time.sleep(0.3)
            raw = get_mock_review(code, language, mode.value, "Claude")
            result = ReviewResult(
                mode=mode,
                language=language,
                raw_response=raw,
                input_tokens=120,
                output_tokens=350,
                latency_ms=_now_ms() - start_ms,
            )
            if mode == PromptMode.STRUCTURED:
                _parse_json_response(result, raw)
            else:
                _parse_text_response(result, raw, mode)
            return result

        system, user_fn = get_prompt(mode)
        user_msg = user_fn(code=code, language=language)

        start_ms = _now_ms()

        try:
            response = self.client.messages.create(
                model=self.MODEL,
                max_tokens=self.MAX_TOKENS,
                system=system,
                messages=[{"role": "user", "content": user_msg}],
            )
        except anthropic.AuthenticationError:
            raise ValueError(
                "Authentication failed. Check your Anthropic API key."
            )
        except anthropic.RateLimitError:
            raise RuntimeError(
                "Rate limit reached. Wait a moment and try again."
            )
        except anthropic.APIError as e:
            raise RuntimeError(f"Anthropic API error: {e}")

        raw = response.content[0].text.strip()

        result = ReviewResult(
            mode=mode,
            language=language,
            raw_response=raw,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            latency_ms=_now_ms() - start_ms,
        )

        if mode == PromptMode.STRUCTURED:
            _parse_json_response(result, raw)
        else:
            _parse_text_response(result, raw, mode)

        return result


# ─────────────────────────────────────────────────────────────
# RESPONSE PARSERS
# ─────────────────────────────────────────────────────────────

def _parse_json_response(result: ReviewResult, raw: str) -> None:
    """
    Parses the JSON object returned by STRUCTURED mode into
    ReviewResult fields.
    """
    # Strip accidental markdown fences the model might add
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = "\n".join(cleaned.split("\n")[1:])
    if cleaned.endswith("```"):
        cleaned = "\n".join(cleaned.split("\n")[:-1])

    try:
        data = json.loads(cleaned.strip())
    except json.JSONDecodeError as e:
        # Fallback — store raw text, leave other fields empty
        result.verdict = f"[Parse error — raw JSON below]\n\n{raw}"
        return

    result.language      = data.get("language", result.language)
    result.understanding = data.get("understanding", "")
    result.refactored_code = data.get("refactored_code", "")
    result.verdict       = data.get("verdict", "")

    for f in data.get("findings", []):
        result.findings.append(Finding(
            line_ref    = f.get("line_ref", "—"),
            category    = f.get("category", "Unknown"),
            severity    = f.get("severity", "Info"),
            description = f.get("description", ""),
            fix_snippet = f.get("fix_snippet", ""),
        ))

    s = data.get("scores", {})
    result.scores = Scores(
        correctness     = int(s.get("correctness",     0)),
        security        = int(s.get("security",        0)),
        readability     = int(s.get("readability",     0)),
        efficiency      = int(s.get("efficiency",      0)),
        maintainability = int(s.get("maintainability", 0)),
    )


def _parse_text_response(
    result: ReviewResult,
    raw: str,
    mode: PromptMode,
) -> None:
    """
    Best-effort parser for Zero-Shot, Few-Shot, and CoT text responses.

    CoT responses are structured around the STEP labels so we can split
    the reasoning chain into individual steps for the UI viewer.
    The extracted steps are stored as a list in result's raw_response
    as a JSON-encoded array (the UI component reads it from there).

    For Zero-Shot and Few-Shot we just extract the verdict line.
    """
    if mode == PromptMode.COT:
        steps = _extract_cot_steps(raw)
        # Store steps alongside raw text — serialised so the UI can read both
        result.raw_response = json.dumps({
            "full_text": raw,
            "steps": steps,
        })
        # Pull verdict from step 5 if found
        if len(steps) >= 5:
            result.verdict = steps[4].get("content", "")
        # Try to extract scores from the text
        result.scores = _extract_scores_from_text(raw)

    else:
        # For ZeroShot/FewShot, look for a "Verdict:" line
        for line in raw.split("\n"):
            if line.lower().startswith("verdict"):
                result.verdict = line.split(":", 1)[-1].strip()
                break


def _extract_cot_steps(text: str) -> list[dict]:
    """
    Splits the CoT response into the 5 labelled steps.

    The COT_SYSTEM prompt instructs the model to label each step as:
      STEP 1 — UNDERSTAND
      STEP 2 — IDENTIFY
      ...etc.

    Returns a list of dicts: [{"step": 1, "title": "...", "content": "..."}, ...]
    """
    step_titles = [
        "UNDERSTAND",
        "IDENTIFY",
        "CLASSIFY",
        "SUGGEST",
        "SCORE AND SUMMARISE",
    ]
    steps = []
    current_step = None
    current_lines: list[str] = []

    for line in text.split("\n"):
        matched = False
        for i, title in enumerate(step_titles, 1):
            # Match "STEP N" with optional separators / dashes
            if f"STEP {i}" in line.upper() and title.split()[0] in line.upper():
                if current_step is not None:
                    steps.append({
                        "step": current_step,
                        "title": step_titles[current_step - 1],
                        "content": "\n".join(current_lines).strip(),
                    })
                current_step = i
                current_lines = []
                matched = True
                break
        if not matched and current_step is not None:
            current_lines.append(line)

    # Flush last step
    if current_step is not None:
        steps.append({
            "step": current_step,
            "title": step_titles[current_step - 1] if current_step <= 5 else "OTHER",
            "content": "\n".join(current_lines).strip(),
        })

    return steps


def _extract_scores_from_text(text: str) -> Scores:
    """
    Attempts to extract numeric scores from the CoT STEP 5 text.

    The model is prompted to write lines like:
      - Correctness: 7
      - Security: 4
    This function parses those lines into a Scores object.
    """
    scores = Scores()
    field_map = {
        "correctness":     "correctness",
        "security":        "security",
        "readability":     "readability",
        "efficiency":      "efficiency",
        "maintainability": "maintainability",
    }

    for line in text.lower().split("\n"):
        for keyword, attr in field_map.items():
            if keyword in line:
                # Find first standalone integer on the line
                for token in line.split():
                    token = token.strip("/:,.()")
                    if token.isdigit() and 1 <= int(token) <= 10:
                        setattr(scores, attr, int(token))
                        break
    return scores


# ─────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────

def _now_ms() -> int:
    return int(time.time() * 1000)


SEVERITY_ORDER = {"Critical": 0, "Major": 1, "Minor": 2, "Info": 3}

def sort_findings(findings: list[Finding]) -> list[Finding]:
    """Sort findings by severity (Critical first)."""
    return sorted(findings, key=lambda f: SEVERITY_ORDER.get(f.severity, 99))


SEVERITY_COLORS = {
    "Critical": "🔴",
    "Major":    "🟠",
    "Minor":    "🟡",
    "Info":     "🔵",
}

CATEGORY_ICONS = {
    "Bug":           "🐛",
    "Security":      "🔒",
    "Performance":   "⚡",
    "Style":         "🎨",
    "Best Practice": "📘",
}
