"""
components/cot_viewer.py
------------------------
Renders the Chain-of-Thought reasoning chain as an expandable
step-by-step panel in Streamlit.

Each of the 5 steps (Understand, Identify, Classify, Suggest, Score)
gets its own expander with an icon, a step header, and the model's
raw reasoning text for that step.

Usage:
    from components.cot_viewer import render_cot_chain
    render_cot_chain(result)   # result: ReviewResult with mode == COT
"""

import json
import streamlit as st
from core.claude_client import ReviewResult, PromptMode


# Step metadata — icon, label, short description shown as caption
STEP_META = [
    {
        "icon":  "🧠",
        "title": "Understand",
        "caption": "What does this code do? Purpose, language, and context.",
    },
    {
        "icon":  "🔎",
        "title": "Identify",
        "caption": "Every potential issue enumerated — no classifications yet.",
    },
    {
        "icon":  "🏷️",
        "title": "Classify",
        "caption": "Each issue tagged with Category, Severity, and line reference.",
    },
    {
        "icon":  "🛠️",
        "title": "Suggest",
        "caption": "Corrected code snippets for every Critical and Major issue.",
    },
    {
        "icon":  "📊",
        "title": "Score & Summarise",
        "caption": "Quality scores out of 10 across 5 dimensions, plus final verdict.",
    },
]


def render_cot_chain(result: ReviewResult) -> None:
    """
    Renders the full CoT reasoning chain from a ReviewResult.

    Only renders if result.mode == PromptMode.COT and the raw_response
    contains the expected JSON structure produced by claude_client._parse_text_response.

    Falls back to plain text display if parsing is unavailable.
    """
    if result.mode != PromptMode.COT:
        st.info("Chain-of-Thought viewer is only available in CoT mode.")
        return

    steps = _extract_steps(result)

    if not steps:
        # Fallback: render raw response as plain text
        st.warning("Could not parse CoT steps — showing raw model output.")
        st.text(result.raw_response)
        return

    st.subheader("🔗 Chain-of-Thought Reasoning")
    st.caption(
        "The model was forced to reason through these 5 steps "
        "before producing its verdict. Expand each step to see the thinking."
    )

    # Progress bar showing how many steps were completed
    completed = len(steps)
    st.progress(completed / 5, text=f"{completed}/5 steps completed")

    for step_data in steps:
        idx   = step_data["step"] - 1
        meta  = STEP_META[idx] if idx < len(STEP_META) else {"icon": "▸", "title": f"Step {idx+1}", "caption": ""}
        icon  = meta["icon"]
        title = meta["title"]
        caption = meta["caption"]

        # Step 1 and the last step default to expanded
        default_open = step_data["step"] in (1, completed)

        with st.expander(
            f"{icon}  Step {step_data['step']} — {title}",
            expanded=default_open,
        ):
            st.caption(caption)
            content = step_data.get("content", "").strip()
            if content:
                st.markdown(content)
            else:
                st.caption("*(No content returned for this step)*")

    # Summary pill row
    _render_step_summary(steps)


def render_cot_mini(result: ReviewResult) -> None:
    """
    Compact version of the CoT chain — shows step titles and first line
    of each step without expanders. Useful in narrow columns (comparison mode).
    """
    steps = _extract_steps(result)
    if not steps:
        return

    for step_data in steps:
        idx   = step_data["step"] - 1
        meta  = STEP_META[idx] if idx < len(STEP_META) else {"icon": "▸", "title": f"Step {idx+1}"}
        first_line = step_data.get("content", "").strip().split("\n")[0][:120]
        st.markdown(
            f"**{meta['icon']} Step {step_data['step']} — {meta['title']}**  \n"
            f"<span style='font-size:12px;color:#6B7280'>{first_line}…</span>",
            unsafe_allow_html=True,
        )


# ── Helpers ────────────────────────────────────────────────────

def _extract_steps(result: ReviewResult) -> list[dict]:
    """
    Parses steps from the ReviewResult.raw_response.

    claude_client._parse_text_response serialises CoT results as:
        JSON { "full_text": "...", "steps": [...] }

    Falls back to empty list on any parse error.
    """
    try:
        data = json.loads(result.raw_response)
        return data.get("steps", [])
    except (json.JSONDecodeError, TypeError):
        return []


def _render_step_summary(steps: list[dict]) -> None:
    """
    Renders a horizontal row of coloured step-completion pills
    below the expanders.
    """
    completed_nums = {s["step"] for s in steps}
    cols = st.columns(5)
    for i, (col, meta) in enumerate(zip(cols, STEP_META), 1):
        done = i in completed_nums
        colour = "#10B981" if done else "#E5E7EB"
        text_colour = "#FFFFFF" if done else "#9CA3AF"
        col.markdown(
            f"<div style='"
            f"background:{colour};color:{text_colour};"
            f"border-radius:8px;padding:4px 0;"
            f"text-align:center;font-size:11px;font-weight:500'>"
            f"{meta['icon']} {meta['title']}"
            f"</div>",
            unsafe_allow_html=True,
        )
