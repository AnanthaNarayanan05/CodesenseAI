"""
components/radar_chart.py
--------------------------
Renders a matplotlib radar (spider) chart for the CodeSense quality scorecard.

Five dimensions:
  Correctness · Security · Readability · Efficiency · Maintainability

Usage:
    from components.radar_chart import render_radar_chart
    from core.claude_client import Scores

    scores = Scores(correctness=7, security=4, readability=8,
                    efficiency=6, maintainability=7)
    fig = render_radar_chart(scores, title="Claude Review")
    st.pyplot(fig)
    plt.close(fig)   # always close to free memory
"""

import math
import matplotlib
matplotlib.use("Agg")          # non-interactive backend (required for Streamlit)
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

from core.claude_client import Scores


# ── Colour palette ─────────────────────────────────────────────
CLAUDE_COLOUR  = "#7C3AED"    # purple
GPT_COLOUR     = "#10A37F"    # OpenAI green
DEFAULT_COLOUR = CLAUDE_COLOUR

FILL_ALPHA   = 0.20
LINE_ALPHA   = 0.90
GRID_COLOUR  = "#E5E7EB"
BG_COLOUR    = "#FFFFFF"
LABEL_COLOUR = "#374151"
TICK_COLOUR  = "#9CA3AF"


DIMENSIONS = [
    "Correctness",
    "Security",
    "Readability",
    "Efficiency",
    "Maintainability",
]


def render_radar_chart(
    scores: Scores,
    title: str = "Code Quality",
    colour: str = DEFAULT_COLOUR,
    figsize: tuple[float, float] = (4.0, 4.0),
) -> plt.Figure:
    """
    Returns a matplotlib Figure containing the radar chart.

    Caller is responsible for calling plt.close(fig) after st.pyplot(fig).
    """
    values = [
        scores.correctness,
        scores.security,
        scores.readability,
        scores.efficiency,
        scores.maintainability,
    ]

    N = len(DIMENSIONS)
    angles = [n / float(N) * 2 * math.pi for n in range(N)]
    angles += angles[:1]           # close the polygon

    vals = values + values[:1]     # close the polygon

    fig, ax = plt.subplots(figsize=figsize, subplot_kw={"polar": True})
    fig.patch.set_facecolor(BG_COLOUR)
    ax.set_facecolor(BG_COLOUR)

    # ── Grid rings ─────────────────────────────────────────────
    ax.set_ylim(0, 10)
    ax.set_yticks([2, 4, 6, 8, 10])
    ax.set_yticklabels(["2", "4", "6", "8", "10"],
                       color=TICK_COLOUR, fontsize=7)
    ax.yaxis.grid(color=GRID_COLOUR, linewidth=0.8, linestyle="--")
    ax.xaxis.grid(color=GRID_COLOUR, linewidth=0.8)
    ax.spines["polar"].set_color(GRID_COLOUR)

    # ── Dimension labels ───────────────────────────────────────
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(
        [f"{d}\n({v}/10)" for d, v in zip(DIMENSIONS, values)],
        color=LABEL_COLOUR,
        fontsize=8,
        fontweight="500",
    )

    # ── Plot data ──────────────────────────────────────────────
    ax.plot(angles, vals, "o-", linewidth=2.0,
            color=colour, alpha=LINE_ALPHA, markersize=4)
    ax.fill(angles, vals, alpha=FILL_ALPHA, color=colour)

    # ── Colour-coded zone rings ────────────────────────────────
    # Red zone 0–4, amber 4–7, green 7–10
    for limit, ring_colour, ring_alpha in [
        (4,  "#EF4444", 0.06),
        (7,  "#F59E0B", 0.05),
        (10, "#10B981", 0.04),
    ]:
        ring_vals = [limit] * N + [limit]
        ax.fill(angles, ring_vals, alpha=ring_alpha, color=ring_colour)

    # ── Average score annotation ───────────────────────────────
    avg = scores.average()
    avg_colour = "#10B981" if avg >= 7 else "#F59E0B" if avg >= 4 else "#EF4444"
    ax.text(
        0, -3.5,
        f"avg  {avg}/10",
        ha="center", va="center",
        fontsize=9, fontweight="600",
        color=avg_colour,
        transform=ax.transData,
    )

    ax.set_title(title, pad=18, fontsize=10,
                 fontweight="600", color=LABEL_COLOUR)

    plt.tight_layout()
    return fig


def render_comparison_chart(
    claude_scores: Scores,
    gpt_scores: Scores,
    figsize: tuple[float, float] = (5.5, 5.0),
) -> plt.Figure:
    """
    Overlays Claude and GPT-4o scores on a single radar chart
    for the comparison panel (U5 — model comparison feature).
    """
    N = len(DIMENSIONS)
    angles = [n / float(N) * 2 * math.pi for n in range(N)]
    angles += angles[:1]

    claude_vals = [
        claude_scores.correctness, claude_scores.security,
        claude_scores.readability, claude_scores.efficiency,
        claude_scores.maintainability,
    ] + [claude_scores.correctness]

    gpt_vals = [
        gpt_scores.correctness, gpt_scores.security,
        gpt_scores.readability, gpt_scores.efficiency,
        gpt_scores.maintainability,
    ] + [gpt_scores.correctness]

    fig, ax = plt.subplots(figsize=figsize, subplot_kw={"polar": True})
    fig.patch.set_facecolor(BG_COLOUR)
    ax.set_facecolor(BG_COLOUR)

    ax.set_ylim(0, 10)
    ax.set_yticks([2, 4, 6, 8, 10])
    ax.set_yticklabels(["2", "4", "6", "8", "10"],
                       color=TICK_COLOUR, fontsize=7)
    ax.yaxis.grid(color=GRID_COLOUR, linewidth=0.8, linestyle="--")
    ax.xaxis.grid(color=GRID_COLOUR, linewidth=0.8)
    ax.spines["polar"].set_color(GRID_COLOUR)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(DIMENSIONS, color=LABEL_COLOUR,
                       fontsize=8, fontweight="500")

    # Claude
    ax.plot(angles, claude_vals, "o-", linewidth=2,
            color=CLAUDE_COLOUR, alpha=LINE_ALPHA, markersize=4,
            label="Claude")
    ax.fill(angles, claude_vals, alpha=FILL_ALPHA, color=CLAUDE_COLOUR)

    # GPT-4o
    ax.plot(angles, gpt_vals, "s--", linewidth=2,
            color=GPT_COLOUR, alpha=LINE_ALPHA, markersize=4,
            label="GPT-4o")
    ax.fill(angles, gpt_vals, alpha=FILL_ALPHA, color=GPT_COLOUR)

    # Legend
    legend_patches = [
        mpatches.Patch(color=CLAUDE_COLOUR, label=f"Claude  {claude_scores.average()}/10"),
        mpatches.Patch(color=GPT_COLOUR,    label=f"GPT-4o  {gpt_scores.average()}/10"),
    ]
    ax.legend(handles=legend_patches, loc="upper right",
              bbox_to_anchor=(1.35, 1.15), fontsize=8, framealpha=0.9)

    ax.set_title("Model Comparison — Quality Scores",
                 pad=18, fontsize=10, fontweight="600", color=LABEL_COLOUR)

    plt.tight_layout()
    return fig
